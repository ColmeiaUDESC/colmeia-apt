# Identidade visual Colmeia

Imagens copiadas sem alterações de `colmeia site/assets/img/`. A licença que acompanha o site foi preservada em `LICENSE`.

- `colmeia-icone.png`: menu, atalhos e instalador.
- `colmeia-logo.png`: logo para fundos claros, usada na tela inicial do instalador.
- `colmeia-logo-claro.png`: logo para fundos escuros, usada no guia e embutida no wallpaper SVG.
- `udesc-cct.png` e `udesc-cct-claro.png`: identificação institucional.
- `mascote.png`: disponível para futuras telas.

Paleta adotada do CSS do site: amarelo `#FFCD2C`, creme `#FFE4A5` e grafite `#414042`.

O ícone também é copiado em `/usr/share/pixmaps/colmeia.png`. Ao atualizar a identidade, sincronizar essas cópias e a imagem embutida no wallpaper. O hook de construção copia o ícone e a logo para o branding do Calamares.
