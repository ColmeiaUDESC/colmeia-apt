def saudacao(nome):
    return f"Olá, {nome}! Vamos construir juntos?"


if __name__ == "__main__":
    print(saudacao("Colmeia"))
