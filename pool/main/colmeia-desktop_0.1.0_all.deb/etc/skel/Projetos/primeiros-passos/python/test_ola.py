from ola import saudacao


def test_saudacao():
    assert saudacao("estudante") == "Olá, estudante! Vamos construir juntos?"
