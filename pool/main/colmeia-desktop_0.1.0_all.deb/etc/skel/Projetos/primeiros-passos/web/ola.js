const linguagens = ["Python", "C", "Java", "JavaScript"];
console.log("Ola, Colmeia! Posso comecar com " + linguagens.join(", ") + ".");
