class Ola {
    public static void main(String[] args) {
        System.out.println("Ola, Colmeia! Meu primeiro programa em Java.");
    }
}
