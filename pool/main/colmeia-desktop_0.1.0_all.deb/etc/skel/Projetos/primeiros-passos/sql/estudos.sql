CREATE TABLE disciplinas (nome TEXT NOT NULL, horas_semanais INTEGER NOT NULL);
INSERT INTO disciplinas VALUES ('Algoritmos', 6), ('Matematica discreta', 4);
SELECT nome, horas_semanais FROM disciplinas ORDER BY horas_semanais DESC;
