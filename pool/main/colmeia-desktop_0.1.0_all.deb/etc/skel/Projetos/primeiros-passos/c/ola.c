#include <stdio.h>

int main(void) {
    puts("Ola, Colmeia! Meu primeiro programa em C.");
    return 0;
}
