# Seus primeiros passos

Abra esta pasta no Dolphin e pressione F4 para abrir um terminal aqui.

```sh
python3 python/ola.py
python3 -m pytest python
gcc -Wall -Wextra -o /tmp/colmeia-ola c/ola.c
/tmp/colmeia-ola
java java/Ola.java
node web/ola.js
sqlite3 :memory: < sql/estudos.sql
```

Modifique as mensagens e execute novamente. Estes exemplos usam apenas ferramentas que fazem parte da receita da Colmeia; não baixam bibliotecas.

Para aprender Git, execute `git init` nesta pasta e acompanhe suas mudanças. Configure seu nome e email antes do primeiro commit. O guia "Comece por aqui — Colmeia", no menu de aplicativos, explica os próximos passos.

Estes exemplos originais são disponibilizados sob licença MIT; veja o arquivo LICENSE nesta pasta, incluído durante a construção da imagem.
