import QtQuick
import QtQuick.Controls as QQC2
import QtQuick.Layouts
import org.kde.kirigami as Kirigami

import org.kde.plasma.welcome

GenericPage {
    heading: "Comece por aqui"
    description: "Atalhos para os primeiros passos na Colmeia Linux. Tudo aqui é software livre."

    topContent: [
        Kirigami.UrlButton {
            Layout.topMargin: Kirigami.Units.largeSpacing
            text: "Site do Colmeia"
            url: "https://colmeiaudesc.github.io/"
        }
    ]

    GridLayout {
        anchors.centerIn: parent
        columns: 2
        rowSpacing: Kirigami.Units.largeSpacing * 2
        columnSpacing: Kirigami.Units.largeSpacing * 2

        Repeater {
            model: [
                { icone: "help-contents", titulo: "Guia da Colmeia", texto: "Como usar o sistema vindo do Windows", comando: "xdg-open /usr/share/colmeia/welcome/index.html" },
                { icone: "folder-development", titulo: "Seus primeiros projetos", texto: "Exemplos em C, Python, Java, SQL e web", comando: "sh -c \"dolphin $HOME/Projetos/primeiros-passos\"" },
                { icone: "utilities-terminal", titulo: "Terminal", texto: "Onde você digita comandos", comando: "konsole" },
                { icone: "plasmadiscover", titulo: "Instalar programas", texto: "Loja de aplicativos livres", comando: "plasma-discover" }
            ]

            delegate: QQC2.Button {
                required property var modelData
                Layout.preferredWidth: Kirigami.Units.gridUnit * 16
                Layout.preferredHeight: Kirigami.Units.gridUnit * 4
                onClicked: Controller.runCommand(modelData.comando)

                contentItem: RowLayout {
                    spacing: Kirigami.Units.largeSpacing
                    Kirigami.Icon {
                        source: modelData.icone
                        Layout.preferredWidth: Kirigami.Units.iconSizes.large
                        Layout.preferredHeight: Kirigami.Units.iconSizes.large
                    }
                    ColumnLayout {
                        spacing: 0
                        Layout.fillWidth: true
                        Kirigami.Heading {
                            text: modelData.titulo
                            level: 4
                            Layout.fillWidth: true
                            wrapMode: Text.Wrap
                        }
                        QQC2.Label {
                            text: modelData.texto
                            opacity: 0.75
                            Layout.fillWidth: true
                            wrapMode: Text.Wrap
                        }
                    }
                }
            }
        }
    }
}
