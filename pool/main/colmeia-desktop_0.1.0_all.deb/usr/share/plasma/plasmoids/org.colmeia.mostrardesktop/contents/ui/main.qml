/*
    Baseado no applet Show Desktop do KDE Plasma 6.3:
    SPDX-FileCopyrightText: 2014 Ashish Madeti <ashishmadeti@gmail.com>
    SPDX-FileCopyrightText: 2016 Kai Uwe Broulik <kde@privat.broulik.de>
    SPDX-FileCopyrightText: 2022 ivan (@ratijas) tkachenko <me@ratijas.tk>
    Modificações: Colmeia UDESC (faixa fina no canto, como no Windows 11)

    SPDX-License-Identifier: GPL-2.0-or-later
*/

import QtQuick
import QtQuick.Layouts

import org.kde.plasma.core as PlasmaCore
import org.kde.kirigami as Kirigami
import org.kde.plasma.plasmoid

PlasmoidItem {
    id: root

    preferredRepresentation: fullRepresentation
    Plasmoid.icon: "user-desktop"
    Plasmoid.title: peek.title
    Plasmoid.onActivated: peek.toggle()
    Plasmoid.backgroundHints: PlasmaCore.Types.NoBackground

    readonly property int largura: 1
    Layout.minimumWidth: largura
    Layout.maximumWidth: largura
    Layout.preferredWidth: largura
    Layout.fillHeight: true

    PeekController { id: peek }

    // Margens do painel ao redor do applet: a faixa estica por cima delas
    // para encostar na borda direita e no topo/base, como no Windows 11.
    readonly property var margensDoPainel: {
        let item = root;
        while (item.parent) {
            item = item.parent;
            if (item.isAppletContainer) {
                return item.getMargins;
            }
        }
        return undefined;
    }
    function margem(lado) {
        return margensDoPainel ? margensDoPainel(lado, true) : 0;
    }

    MouseArea {
        id: area
        anchors {
            fill: parent
            topMargin: -root.margem("top")
            bottomMargin: -root.margem("bottom")
            rightMargin: -root.margem("right")
        }
        hoverEnabled: true
        onClicked: Plasmoid.activated()

        Rectangle {
            anchors.fill: parent
            color: Kirigami.Theme.highlightColor
            opacity: peek.active ? 0.55 : (area.containsMouse ? 0.35 : 0)
            Behavior on opacity { NumberAnimation { duration: Kirigami.Units.shortDuration } }
        }

        // linha divisória à esquerda, igual à do Windows 11
        Rectangle {
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: 1
            color: Kirigami.Theme.textColor
            opacity: 0.35
        }

        DropArea {
            anchors.fill: parent
            onEntered: abrirAoArrastar.start()
            onExited: abrirAoArrastar.stop()
        }

        Timer {
            id: abrirAoArrastar
            interval: 250
            onTriggered: Plasmoid.activated()
        }

        PlasmaCore.ToolTipArea {
            anchors.fill: parent
            mainText: peek.title
            subText: peek.description
        }
    }
}
