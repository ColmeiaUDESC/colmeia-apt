/*
    SPDX-FileCopyrightText: 2022 ivan (@ratijas) tkachenko <me@ratijas.tk>

    SPDX-License-Identifier: GPL-2.0-or-later
*/

import org.kde.plasma.private.showdesktop 0.1
import org.kde.plasma.plasmoid 2.0


Controller {
    id: controller

    titleInactive: "Mostrar área de trabalho"
    titleActive: Plasmoid.containment.corona.editMode ? titleInactive : "Voltar às janelas"

    descriptionActive: "Traz as janelas de volta"
    descriptionInactive: "Esconde as janelas para mostrar a área de trabalho"

    active: showdesktop.showingDesktop

    // override
    function toggle() {
        showdesktop.toggleDesktop();
    }

    readonly property ShowDesktop showdesktop: ShowDesktop {
        id: showdesktop
    }
}
