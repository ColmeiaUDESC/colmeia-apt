// Colmeia: "Todos" em pastas por categoria, como a visualização "Categoria" do Windows 11.
import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents

Item {
    id: categorias

    property var modeloCategorias
    property int margem: 32
    readonly property int colunas: 4
    readonly property int espaco: 16
    readonly property int lado: Math.floor((width - margem * 2 - espaco * (colunas - 1)) / colunas)

    signal abrirCategoria(var modelo, string nome)
    signal trocarVisao()

    height: cabecalho.height + 14 + grade.height

    Item {
        id: cabecalho
        x: categorias.margem
        width: categorias.width - categorias.margem * 2
        height: 22

        PlasmaComponents.Label {
            text: "Todos"
            font.bold: true
            font.pixelSize: 15
        }

        PlasmaComponents.Label {
            anchors.right: parent.right
            text: "Visualização: Categoria  ▾"
            font.pixelSize: 13
            opacity: visaoMouse.containsMouse ? 1 : 0.8

            MouseArea {
                id: visaoMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: categorias.trocarVisao()
            }
        }
    }

    Grid {
        id: grade
        x: categorias.margem
        y: cabecalho.height + 14
        columns: categorias.colunas
        columnSpacing: categorias.espaco
        rowSpacing: categorias.espaco

        Repeater {
            model: categorias.modeloCategorias

            delegate: Item {
                id: pasta
                required property int index
                required property var model
                readonly property var filhos: categorias.modeloCategorias
                    ? categorias.modeloCategorias.modelForRow(index) : null

                visible: !!filhos && filhos.count > 0
                width: categorias.lado
                height: categorias.lado + 30

                Rectangle {
                    id: quadro
                    width: parent.width
                    height: categorias.lado
                    radius: 8
                    color: Kirigami.Theme.textColor
                    opacity: pastaMouse.containsMouse ? 0.10 : 0.05
                }

                Rectangle {
                    anchors.fill: quadro
                    radius: 8
                    color: "transparent"
                    border.width: 1
                    border.color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.08)
                }

                Grid {
                    anchors.centerIn: quadro
                    columns: 2
                    spacing: Math.round(categorias.lado * 0.12)

                    Repeater {
                        model: pasta.filhos

                        delegate: Kirigami.Icon {
                            required property int index
                            required property var model
                            visible: index < 4
                            width: Math.round(categorias.lado * 0.26)
                            height: width
                            source: model.decoration
                        }
                    }
                }

                PlasmaComponents.Label {
                    anchors.top: quadro.bottom
                    anchors.topMargin: 6
                    width: parent.width
                    horizontalAlignment: Text.AlignHCenter
                    elide: Text.ElideRight
                    text: pasta.model.display || ""
                    font.pixelSize: 12
                }

                MouseArea {
                    id: pastaMouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: categorias.abrirCategoria(pasta.filhos, pasta.model.display || "")
                }
            }
        }
    }
}
