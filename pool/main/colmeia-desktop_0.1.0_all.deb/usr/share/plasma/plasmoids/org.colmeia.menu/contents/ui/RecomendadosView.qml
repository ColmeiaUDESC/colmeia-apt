// Colmeia: seção "Recomendados" (apps e arquivos usados recentemente), como no Windows 11.
import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents
import org.kde.plasma.private.kicker as Kicker

Item {
    id: recomendados

    property int margem: 32
    readonly property int colunas: 3
    readonly property int maximo: 6
    readonly property var modelo: recentes
    readonly property bool vazio: recentes.count === 0

    signal fecharMenu()
    signal abrirTudo()

    visible: !vazio
    height: vazio ? 0 : titulo.height + 14 + grade.height

    Kicker.RecentUsageModel {
        id: recentes
        shownItems: Kicker.RecentUsageModel.AppsAndDocs
        ordering: Kicker.RecentUsageModel.Recent
    }

    PlasmaComponents.Label {
        id: titulo
        x: recomendados.margem
        text: "Recomendados"
        font.bold: true
        font.pixelSize: 15
    }

    PlasmaComponents.Label {
        anchors.right: parent.right
        anchors.rightMargin: recomendados.margem
        y: 2
        visible: false // Colmeia: sem "Mostrar tudo" nos Recomendados
        text: "Mostrar tudo  ›"
        font.pixelSize: 13
        opacity: tudoMouse.containsMouse ? 1 : 0.8

        MouseArea {
            id: tudoMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: recomendados.abrirTudo()
        }
    }

    Grid {
        id: grade
        x: recomendados.margem
        y: titulo.height + 14
        width: recomendados.width - recomendados.margem * 2
        columns: recomendados.colunas
        rowSpacing: 6
        columnSpacing: 8

        Repeater {
            model: recentes

            delegate: Item {
                id: item
                required property int index
                required property var model

                visible: index < recomendados.maximo
                width: (grade.width - grade.columnSpacing * (recomendados.colunas - 1)) / recomendados.colunas
                height: 50

                Rectangle {
                    anchors.fill: parent
                    radius: 6
                    color: Kirigami.Theme.textColor
                    opacity: mouse.containsMouse ? 0.07 : 0
                }

                Kirigami.Icon {
                    id: icone
                    x: 10
                    anchors.verticalCenter: parent.verticalCenter
                    width: 30
                    height: 30
                    source: item.model.decoration
                }

                Column {
                    anchors {
                        left: icone.right
                        leftMargin: 10
                        right: parent.right
                        rightMargin: 8
                        verticalCenter: parent.verticalCenter
                    }

                    PlasmaComponents.Label {
                        width: parent.width
                        text: item.model.display || ""
                        elide: Text.ElideRight
                        font.pixelSize: 13
                    }
                    PlasmaComponents.Label {
                        width: parent.width
                        text: item.model.description || "Usado recentemente"
                        elide: Text.ElideRight
                        font.pixelSize: 11
                        opacity: 0.65
                    }
                }

                MouseArea {
                    id: mouse
                    anchors.fill: parent
                    hoverEnabled: true
                    cursorShape: Qt.PointingHandCursor
                    onClicked: {
                        recentes.trigger(item.index, "", null)
                        recomendados.fecharMenu()
                    }
                }
            }
        }
    }
}
