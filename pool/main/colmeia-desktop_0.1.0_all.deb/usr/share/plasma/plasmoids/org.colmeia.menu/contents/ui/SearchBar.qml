import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents

Rectangle {
    id: searchBar

    property string searchText: ""
    property string placeholderText: ""

    signal searchTextEdited(string text)

    function focusSearchField() {
        searchField.forceActiveFocus()
    }

    height: 46
    radius: 23
    color: Kirigami.Theme.backgroundColor
    border.color: Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
    border.width: 1

    Text {
        anchors.left: parent.left
        anchors.leftMargin: 20
        anchors.verticalCenter: parent.verticalCenter

        text: "⌕"
        color: Kirigami.Theme.focusColor
        font.pixelSize: 25
    }

    PlasmaComponents.TextField {
        id: searchField

        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter

        leftPadding: 52
        rightPadding: 16

        placeholderText: searchBar.placeholderText
        background: null
        font.pixelSize: 15
        text: searchBar.searchText

        onTextEdited: {
            searchBar.searchTextEdited(text)
        }
    }
}