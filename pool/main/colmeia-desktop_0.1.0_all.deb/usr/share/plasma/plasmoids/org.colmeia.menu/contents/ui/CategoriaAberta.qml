// Colmeia: conteúdo de uma categoria aberta (ao clicar numa pasta de "Todos").
import QtQuick
import QtQuick.Controls as Controls
import org.kde.kirigami as Kirigami
import org.kde.plasma.components as PlasmaComponents

Rectangle {
    id: aberta

    property var modelo: null
    property string nome: ""
    readonly property int colunas: 6

    signal fecharMenu()

    function abrir(novoModelo, novoNome) {
        modelo = novoModelo
        nome = novoNome
    }
    function fechar() {
        modelo = null
    }

    visible: modelo !== null
    color: Qt.rgba(Kirigami.Theme.backgroundColor.r, Kirigami.Theme.backgroundColor.g, Kirigami.Theme.backgroundColor.b, 0.97)

    // clique fora dos itens não passa para o menu por baixo
    MouseArea { anchors.fill: parent }

    PlasmaComponents.ToolButton {
        id: voltar
        x: 24
        y: 24
        icon.name: "go-previous"
        text: aberta.nome
        font.bold: true
        onClicked: aberta.fechar()
    }

    GridView {
        id: grade
        anchors {
            top: voltar.bottom
            topMargin: 16
            left: parent.left
            leftMargin: 32
            right: parent.right
            rightMargin: 32
            bottom: parent.bottom
            bottomMargin: 80
        }
        clip: true
        model: aberta.modelo
        cellWidth: Math.floor(width / aberta.colunas)
        cellHeight: 92
        Controls.ScrollBar.vertical: Controls.ScrollBar {}

        delegate: Item {
            id: app
            required property int index
            required property var model
            width: grade.cellWidth
            height: grade.cellHeight

            Rectangle {
                anchors.fill: parent
                anchors.margins: 4
                radius: 6
                color: Kirigami.Theme.textColor
                opacity: appMouse.containsMouse ? 0.07 : 0
            }

            Kirigami.Icon {
                id: icone
                anchors.horizontalCenter: parent.horizontalCenter
                y: 12
                width: 36
                height: 36
                source: app.model.decoration
            }

            PlasmaComponents.Label {
                anchors.top: icone.bottom
                anchors.topMargin: 6
                width: parent.width - 8
                x: 4
                horizontalAlignment: Text.AlignHCenter
                elide: Text.ElideRight
                text: app.model.display || ""
                font.pixelSize: 12
            }

            MouseArea {
                id: appMouse
                anchors.fill: parent
                hoverEnabled: true
                cursorShape: Qt.PointingHandCursor
                onClicked: {
                    aberta.modelo.trigger(app.index, "", null)
                    aberta.fechar()
                    aberta.fecharMenu()
                }
            }
        }
    }
}
