# Menu Colmeia

Menu iniciar da Colmeia Linux no estilo do Windows 11.

Baseado no [Windows 11 Start Menu](https://github.com/wOOtiTv/tv.wooti.win11menu), de wOOtiTv, versão 1.3.3, licenciado sob GPL-2.0-or-later (veja LICENSE). Modificações da Colmeia: identidade, cores do tema, ícone e tradução para o português.
