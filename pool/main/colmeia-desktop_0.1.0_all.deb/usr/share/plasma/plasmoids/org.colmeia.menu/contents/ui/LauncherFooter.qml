import QtQuick
import Qt5Compat.GraphicalEffects
import org.kde.plasma.plasmoid
import org.kde.plasma.components as PlasmaComponents
import org.kde.kirigami as Kirigami
import org.kde.coreaddons as KCoreAddons
import org.kde.kcmutils as KCMUtils

Rectangle {
    id: footer

    property var sessionManager

    property bool showLockButton: true
    property bool showLogoutButton: true
    property bool showRestartButton: true
    property bool showShutdownButton: true
    readonly property bool showSessionButtonLabels:
        Plasmoid.configuration.showSessionButtonLabels !== false
    readonly property string sessionButtonAlignment:
        String(Plasmoid.configuration.sessionButtonAlignment || "right")
    readonly property bool leftSessionButtons:
        sessionButtonAlignment === "left"
    readonly property bool centerSessionButtons:
        sessionButtonAlignment === "center"
    readonly property int sessionIconSize: 20
    readonly property int compactButtonWidth: 40
    readonly property int compactButtonHeight: 40

    property string lockText: ""
    property string logoutText: ""
    property string restartText: ""
    property string shutdownText: ""

    signal closeLauncherRequested()

    // rodapé reto com uma linha em cima, como no Windows 11
    height: 64
    radius: 0
    // fica por cima da lista, que rola por baixo dele
    color: Qt.rgba(Kirigami.Theme.backgroundColor.r, Kirigami.Theme.backgroundColor.g, Kirigami.Theme.backgroundColor.b, 0.96)

    Rectangle {
        anchors { top: parent.top; left: parent.left; right: parent.right }
        height: 1
        color: Qt.rgba(Kirigami.Theme.textColor.r, Kirigami.Theme.textColor.g, Kirigami.Theme.textColor.b, 0.12)
    }

    KCoreAddons.KUser {
        id: currentUser
    }

    Item {
        id: userInfo

        visible: Plasmoid.configuration.showUserInfo
            && !footer.leftSessionButtons

        anchors.left: parent.left
        anchors.leftMargin: 24

        anchors.verticalCenter: parent.verticalCenter

        width: Math.max(
            120,
            Math.min(250, sessionActions.x - 40)
        )
        height: 48

        // Colmeia: clicar no perfil abre as opções da conta, como no Windows 11
        Rectangle {
            anchors.fill: parent
            anchors.margins: -4
            radius: 8
            color: Kirigami.Theme.textColor
            opacity: perfilMouse.containsMouse ? 0.08 : 0
        }

        MouseArea {
            id: perfilMouse
            anchors.fill: parent
            hoverEnabled: true
            cursorShape: Qt.PointingHandCursor
            onClicked: menuPerfil.popup(userInfo, 0, -menuPerfil.implicitHeight - 4)
        }

        PlasmaComponents.Menu {
            id: menuPerfil

            PlasmaComponents.MenuItem {
                text: "Configurações da conta"
                icon.name: "system-users"
                onTriggered: {
                    footer.closeLauncherRequested()
                    KCMUtils.KCMLauncher.openSystemSettings("kcm_users")
                }
            }
            PlasmaComponents.MenuItem {
                text: "Bloquear"
                icon.name: "system-lock-screen"
                enabled: footer.sessionManager && footer.sessionManager.canLock
                onTriggered: { footer.closeLauncherRequested(); footer.sessionManager.lock() }
            }
            PlasmaComponents.MenuItem {
                text: "Sair"
                icon.name: "system-log-out"
                enabled: footer.sessionManager && footer.sessionManager.canLogout
                onTriggered: footer.sessionManager.requestLogout(1)
            }
        }

        Rectangle {
            id: avatarFrame


            width: 32
            height: 32

            anchors.left: parent.left
            anchors.verticalCenter: parent.verticalCenter

            radius: width / 2
            color: Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
            clip: true

            Image {
                id: userAvatar

                anchors.fill: parent
                source: currentUser.faceIconUrl
                fillMode: Image.PreserveAspectCrop
                asynchronous: true
                cache: false
            }

            OpacityMask {
                anchors.fill: userAvatar
                source: userAvatar
                maskSource: avatarMask
                visible: userAvatar.status === Image.Ready
            }

            Rectangle {
                id: avatarMask

                anchors.fill: parent
                radius: width / 2
                color: "white"
                visible: false
            }

            Kirigami.Icon {
                anchors.centerIn: parent
                width: 24
                height: 24
                source: "user"
                visible: userAvatar.status !== Image.Ready
            }
        }

        PlasmaComponents.Label {
            anchors.left: avatarFrame.right
            anchors.leftMargin: 12
            anchors.right: parent.right
            anchors.verticalCenter: avatarFrame.verticalCenter

            text: currentUser.fullName
            font.pixelSize: 15
            font.bold: true
            maximumLineCount: 1
            elide: Text.ElideRight
        }
    }

    Row {
        id: sessionActions

        x: footer.leftSessionButtons
            ? 24
            : (footer.centerSessionButtons
                ? Math.round((parent.width - width) / 2)
                : parent.width - width - 24)
        anchors.verticalCenter: parent.verticalCenter

        spacing: 8

        Rectangle {
            id: lockButton

            visible: footer.showLockButton
            width: footer.showSessionButtonLabels
                ? Math.max(118, lockContent.implicitWidth + 28)
                : footer.compactButtonWidth
            height: footer.showSessionButtonLabels
                ? 42
                : footer.compactButtonHeight
            radius: 12

            color: lockMouse.containsMouse
                ? Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
                : "transparent"

            opacity: footer.sessionManager && footer.sessionManager.canLock ? 1 : 0.45

            Behavior on color {
                ColorAnimation { duration: 120 }
            }

            Row {
                id: lockContent

                anchors.centerIn: parent
                spacing: footer.showSessionButtonLabels ? 8 : 0

                Kirigami.Icon {
                    width: footer.sessionIconSize
                    height: width
                    source: "system-lock-screen"
                }

                PlasmaComponents.Label {
                    visible: footer.showSessionButtonLabels
                    height: 20
                    verticalAlignment: Text.AlignVCenter
                    text: footer.lockText
                    font.pixelSize: 13
                }
            }

            MouseArea {
                id: lockMouse

                anchors.fill: parent
                hoverEnabled: true
                enabled: footer.sessionManager ? footer.sessionManager.canLock : false
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor

                onClicked: {
                    footer.closeLauncherRequested()
                    footer.sessionManager.lock()
                }
            }
        }

        Rectangle {
            id: logoutButton

            visible: footer.showLogoutButton
            width: footer.showSessionButtonLabels
                ? Math.max(118, logoutContent.implicitWidth + 28)
                : footer.compactButtonWidth
            height: footer.showSessionButtonLabels
                ? 42
                : footer.compactButtonHeight
            radius: 12

            color: logoutMouse.containsMouse
                ? Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
                : "transparent"

            opacity: footer.sessionManager && footer.sessionManager.canLogout ? 1 : 0.45

            Behavior on color {
                ColorAnimation { duration: 120 }
            }

            Row {
                id: logoutContent

                anchors.centerIn: parent
                spacing: footer.showSessionButtonLabels ? 8 : 0

                Kirigami.Icon {
                    width: footer.sessionIconSize
                    height: width
                    source: "system-log-out"
                }

                PlasmaComponents.Label {
                    visible: footer.showSessionButtonLabels
                    height: 20
                    verticalAlignment: Text.AlignVCenter
                    text: footer.logoutText
                    font.pixelSize: 13
                }
            }

            MouseArea {
                id: logoutMouse

                anchors.fill: parent
                hoverEnabled: true
                enabled: footer.sessionManager ? footer.sessionManager.canLogout : false
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor

                onClicked: {
                    footer.sessionManager.requestLogout(1)
                }
            }
        }

        Rectangle {
            id: rebootButton

            visible: footer.showRestartButton
            width: footer.showSessionButtonLabels
                ? Math.max(112, rebootContent.implicitWidth + 28)
                : footer.compactButtonWidth
            height: footer.showSessionButtonLabels
                ? 42
                : footer.compactButtonHeight
            radius: 12

            color: rebootMouse.containsMouse
                ? Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
                : "transparent"

            opacity: footer.sessionManager && footer.sessionManager.canReboot ? 1 : 0.45

            Behavior on color {
                ColorAnimation { duration: 120 }
            }

            Row {
                id: rebootContent

                anchors.centerIn: parent
                spacing: footer.showSessionButtonLabels ? 8 : 0

                Kirigami.Icon {
                    width: footer.sessionIconSize
                    height: width
                    source: "system-reboot"
                }

                PlasmaComponents.Label {
                    visible: footer.showSessionButtonLabels
                    height: 20
                    verticalAlignment: Text.AlignVCenter
                    text: footer.restartText
                    font.pixelSize: 13
                }
            }

            MouseArea {
                id: rebootMouse

                anchors.fill: parent
                hoverEnabled: true
                enabled: footer.sessionManager ? footer.sessionManager.canReboot : false
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor

                onClicked: {
                    footer.sessionManager.requestReboot(1)
                }
            }
        }

        Rectangle {
            id: shutdownButton

            visible: footer.showShutdownButton
            width: footer.showSessionButtonLabels
                ? Math.max(108, shutdownContent.implicitWidth + 28)
                : footer.compactButtonWidth
            height: footer.showSessionButtonLabels
                ? 42
                : footer.compactButtonHeight
            radius: 12

            color: shutdownMouse.containsMouse
                ? Qt.rgba(Kirigami.Theme.highlightColor.r, Kirigami.Theme.highlightColor.g, Kirigami.Theme.highlightColor.b, 0.3)
                : "transparent"

            opacity: footer.sessionManager && footer.sessionManager.canShutdown ? 1 : 0.45

            Behavior on color {
                ColorAnimation { duration: 120 }
            }

            Row {
                id: shutdownContent

                anchors.centerIn: parent
                spacing: footer.showSessionButtonLabels ? 8 : 0

                Kirigami.Icon {
                    width: footer.sessionIconSize
                    height: width
                    source: "system-shutdown"
                }

                PlasmaComponents.Label {
                    visible: footer.showSessionButtonLabels
                    height: 20
                    verticalAlignment: Text.AlignVCenter
                    text: footer.shutdownText
                    font.pixelSize: 13
                }
            }

            MouseArea {
                id: shutdownMouse

                anchors.fill: parent
                hoverEnabled: true
                enabled: footer.sessionManager ? footer.sessionManager.canShutdown : false
                cursorShape: enabled ? Qt.PointingHandCursor : Qt.ArrowCursor

                // Colmeia: como no Windows 11, um botão só que abre as opções
                onClicked: menuEnergia.popup(shutdownButton, 0, -menuEnergia.implicitHeight - 4)
            }

            PlasmaComponents.Menu {
                id: menuEnergia

                PlasmaComponents.MenuItem {
                    text: "Bloquear"
                    icon.name: "system-lock-screen"
                    enabled: footer.sessionManager && footer.sessionManager.canLock
                    onTriggered: { footer.closeLauncherRequested(); footer.sessionManager.lock() }
                }
                PlasmaComponents.MenuItem {
                    text: "Suspender"
                    icon.name: "system-suspend"
                    enabled: footer.sessionManager && footer.sessionManager.canSuspend
                    onTriggered: { footer.closeLauncherRequested(); footer.sessionManager.suspend() }
                }
                PlasmaComponents.MenuItem {
                    text: "Sair"
                    icon.name: "system-log-out"
                    enabled: footer.sessionManager && footer.sessionManager.canLogout
                    onTriggered: footer.sessionManager.requestLogout(1)
                }
                PlasmaComponents.MenuSeparator {}
                PlasmaComponents.MenuItem {
                    text: "Reiniciar"
                    icon.name: "system-reboot"
                    enabled: footer.sessionManager && footer.sessionManager.canReboot
                    onTriggered: footer.sessionManager.requestReboot(1)
                }
                PlasmaComponents.MenuItem {
                    text: "Desligar"
                    icon.name: "system-shutdown"
                    enabled: footer.sessionManager && footer.sessionManager.canShutdown
                    onTriggered: footer.sessionManager.requestShutdown(1)
                }
            }
        }
    }
}

