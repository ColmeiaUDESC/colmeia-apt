import QtQuick

Rectangle {
    id: root
    color: "#2a292b"

    property int stage

    Image {
        id: logo
        anchors.centerIn: parent
        anchors.verticalCenterOffset: -30
        source: "images/logo.png"
        width: 360
        fillMode: Image.PreserveAspectFit
        smooth: true
        opacity: 0
        OpacityAnimator on opacity { from: 0; to: 1; duration: 700; running: true }
    }

    Row {
        anchors.top: logo.bottom
        anchors.topMargin: 48
        anchors.horizontalCenter: parent.horizontalCenter
        spacing: 10

        Repeater {
            model: 6
            Image {
                source: index < root.stage ? "images/hex-on.png" : "images/hex-off.png"
                width: 21
                height: 24
                smooth: true
            }
        }
    }

    Text {
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 32
        anchors.horizontalCenter: parent.horizontalCenter
        text: "Colmeia Linux"
        color: "#8a8680"
        font.pixelSize: 14
    }
}
