// Painel no estilo do Windows 11: menu e aplicativos centralizados,
// bandeja e relógio à direita e a faixa fina de "mostrar área de trabalho" no canto.
var panel = new Panel;
panel.location = "bottom";
panel.height = 48;
panel.floating = false;
// translúcida com desfoque, como no Windows 11 (dá para trocar em Editar painel)
panel.opacity = "translucent";

panel.addWidget("org.kde.plasma.panelspacer");

// org.colmeia.menu (estilo Windows 11) derruba o plasmashell 6.3 dentro do
// libkickerplugin; até ser corrigido, o painel usa o Kickoff oficial.
var menu = panel.addWidget("org.colmeia.menu");
menu.currentConfigGroup = ["General"];
menu.writeConfig("icon", "colmeia-menu");
// Tecla Windows (Meta) abre o menu: o KWin manda Meta para o atalho do lançador
menu.currentConfigGroup = ["Shortcuts"];
menu.writeConfig("global", "Alt+F1");

var tasks = panel.addWidget("org.kde.plasma.icontasks");
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("fill", false);
tasks.writeConfig("iconSpacing", 1);
// Apps fixados viram o próprio app quando abertos (não aparecem duas vezes)
tasks.writeConfig("separateLaunchers", false);
// Sempre agrupa as janelas do mesmo programa
tasks.writeConfig("groupingStrategy", 1);
tasks.writeConfig("onlyGroupWhenFull", false);
// Clicar num grupo mostra as miniaturas das janelas
tasks.writeConfig("groupedTaskVisualization", 1);
tasks.writeConfig("showToolTips", true);
tasks.writeConfig("highlightWindows", true);
tasks.writeConfig("minimizeActiveTaskOnClick", true);
// No Windows a rodinha do mouse sobre a barra não troca de janela
tasks.writeConfig("wheelEnabled", false);
// Botão do meio abre outra janela do programa (igual ao Windows)
tasks.writeConfig("middleClickAction", 2);
// Ícone pisca/ganha destaque quando o app pede atenção
tasks.writeConfig("unhideOnAttention", true);
tasks.writeConfig("interactiveMute", true);
var lancadores = [
    "applications:org.kde.dolphin.desktop",
    "applications:firefox-esr.desktop",
    "applications:codium.desktop",
    "applications:org.kde.konsole.desktop",
    "applications:org.kde.discover.desktop"
];
// No live (onde o Calamares existe) o instalador também fica fixado na barra
if (applicationExists("calamares-install-debian.desktop")) {
    lancadores.unshift("applications:calamares-install-debian.desktop");
}
tasks.writeConfig("launchers", lancadores);

panel.addWidget("org.kde.plasma.panelspacer");
var bandeja = panel.addWidget("org.kde.plasma.systemtray");
// Notificações ficam fora da bandeja, entre o relógio e a faixa da área de
// trabalho (como no Windows). A bandeja só adiciona sozinha os itens que ainda
// não "conhece"; marcar as notificações como conhecidas evita que ela entre.
try {
    var bandejaInterna = desktopById(bandeja.readConfig("SystrayContainmentId"));
    bandejaInterna.currentConfigGroup = ["General"];
    function comoLista(v) {
        if (!v) return [];
        return (typeof v === "string") ? v.split(",").filter(function (x) { return x; }) : Array.prototype.slice.call(v);
    }
    var conhecidos = comoLista(bandejaInterna.readConfig("knownItems"));
    if (conhecidos.indexOf("org.kde.plasma.notifications") < 0) {
        conhecidos.push("org.kde.plasma.notifications");
    }
    bandejaInterna.writeConfig("knownItems", conhecidos);
    var ativos = comoLista(bandejaInterna.readConfig("extraItems")).filter(function (id) {
        return id !== "org.kde.plasma.notifications";
    });
    bandejaInterna.writeConfig("extraItems", ativos);
} catch (e) {
    print("colmeia: não consegui configurar a bandeja: " + e);
}

// Relógio: hora em cima, data embaixo, mesma fonte pequena
var relogio = panel.addWidget("org.colmeia.relogio");
relogio.currentConfigGroup = ["Appearance"];
relogio.writeConfig("showDate", true);
relogio.writeConfig("dateFormat", "shortDate");
relogio.writeConfig("dateDisplayFormat", 2);
relogio.writeConfig("autoFontAndSize", false);
relogio.writeConfig("fontFamily", "Inter");
relogio.writeConfig("fontWeight", 400);
relogio.writeConfig("fontSize", 7);
relogio.writeConfig("showSeconds", 0);

panel.addWidget("org.kde.plasma.notifications");
panel.addWidget("org.colmeia.mostrardesktop");

var allDesktops = desktops();
for (var i = 0; i < allDesktops.length; i++) {
    var desktop = allDesktops[i];
    desktop.wallpaperPlugin = "org.kde.image";
    desktop.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desktop.writeConfig("Image", "file:///usr/share/wallpapers/Colmeia/contents/images/1920x1080.svg");
}
