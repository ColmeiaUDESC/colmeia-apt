#!/bin/sh
# Volta os arquivos do KDE ao original (usado ao remover o colmeia-desktop).
find /usr/share/plasma/plasmoids -name '*.colmeia-orig' | while read -r orig; do
    mv -f "$orig" "${orig%.colmeia-orig}"
done
rm -f /usr/local/share/applications/org.kde.plasma-welcome.desktop \
      /usr/local/share/applications/org.kde.khelpcenter.desktop
exit 0
