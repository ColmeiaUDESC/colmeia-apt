#!/usr/bin/env python3
"""Barra de tarefas no estilo do Windows 11 (patch sobre o KDE Plasma 6.3).

- esconde o fundo/linha do tema do KDE em cada app;
- desenha um tracinho embaixo, centralizado: curto e cinza nos apps abertos,
  mais comprido e na cor de destaque no app em foco;
- fundo arredondado leve no app em foco e ao passar o mouse;
- "pilha" atrás do ícone quando o app tem várias janelas.

Aplica sobre os arquivos instalados pelo Debian e sempre parte do original
(cópia .colmeia-orig), então pode rodar de novo quantas vezes precisar.
"""
import sys
from pathlib import Path

UI = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/share/plasma/plasmoids/org.kde.plasma.taskmanager/contents/ui")
MARCA = "// colmeia-tarefas"
avisos = []

arq = UI / "Task.qml"
orig = arq.with_name(arq.name + ".colmeia-orig")
if MARCA not in arq.read_text(encoding="utf-8"):
    orig.write_bytes(arq.read_bytes())  # original do KDE (instalação nova ou atualização)
elif orig.exists():
    arq.write_bytes(orig.read_bytes())
else:
    sys.exit("colmeia-tarefas: Task.qml já tem patch antigo e não há original; reinstale o plasma-desktop-data")

texto = arq.read_text(encoding="utf-8")


def trocar(antes, depois):
    global texto
    if antes not in texto:
        avisos.append(f"trecho não encontrado: {antes.strip()[:60]!r}")
        return
    texto = texto.replace(antes, depois, 1)


# esconde o desenho do tema (o DragHandler dentro do frame continua funcionando)
trocar('        imagePath: "widgets/tasks"\n',
       f'        imagePath: "widgets/tasks"\n        {MARCA}\n        opacity: task.inPopup ? 1 : 0\n')

ESTILO = f'''    {MARCA}: desenho no estilo do Windows 11
    readonly property bool colmeiaAberto: !task.inPopup && !model.IsLauncher
    readonly property bool colmeiaVarias: colmeiaAberto && model.IsGroupParent && task.childCount > 1
    readonly property real colmeiaFundo: task.inPopup ? 0
        : (model.IsActive ? 0.12 : (frame.isHovered ? 0.08 : 0))

    Rectangle {{
        id: colmeiaPilha
        visible: task.colmeiaVarias
        anchors {{
            fill: colmeiaFundoItem
            leftMargin: 3
            rightMargin: -3
        }}
        radius: 5
        color: "transparent"
        border.width: 1
        border.color: Kirigami.Theme.textColor
        opacity: 0.25
    }}

    Rectangle {{
        id: colmeiaFundoItem
        anchors {{
            fill: frame
            margins: 3
            rightMargin: task.colmeiaVarias ? 6 : 3
        }}
        radius: 5
        color: Kirigami.Theme.textColor
        opacity: task.colmeiaFundo
        Behavior on opacity {{ NumberAnimation {{ duration: Kirigami.Units.shortDuration }} }}
    }}

    Rectangle {{
        id: colmeiaIndicador
        visible: task.colmeiaAberto
        anchors {{
            bottom: frame.bottom
            bottomMargin: 2
            horizontalCenter: colmeiaFundoItem.horizontalCenter
        }}
        height: 3
        radius: 1.5
        width: model.IsActive ? 16 : 6
        color: model.IsDemandingAttention ? Kirigami.Theme.negativeTextColor
             : (model.IsActive ? Kirigami.Theme.highlightColor : Kirigami.Theme.disabledTextColor)
        Behavior on width {{ NumberAnimation {{ duration: Kirigami.Units.shortDuration }} }}
    }}

    Loader {{
        id: taskProgressOverlayLoader
'''
trocar("    Loader {\n        id: taskProgressOverlayLoader\n", ESTILO)

arq.write_text(texto, encoding="utf-8")
for aviso in avisos:
    print("colmeia-tarefas: AVISO", aviso, file=sys.stderr)
print("colmeia-tarefas: patch aplicado" + (" com avisos" if avisos else ""))
