#!/usr/bin/env python3
"""Sininho de notificações do tamanho dos ícones da bandeja (patch sobre o KDE Plasma 6.3).

No painel o ícone ocupava a altura toda da barra; limita a iconSizes.smallMedium.
Sempre parte do original (.colmeia-orig), então pode rodar de novo.
"""
import sys
from pathlib import Path

UI = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/share/plasma/plasmoids/org.kde.plasma.notifications/contents/ui")
MARCA = "// colmeia-notificacoes"

arq = UI / "CompactRepresentation.qml"
orig = arq.with_name(arq.name + ".colmeia-orig")
if MARCA not in arq.read_text(encoding="utf-8"):
    orig.write_bytes(arq.read_bytes())  # original do KDE (instalação nova ou atualização)
elif orig.exists():
    arq.write_bytes(orig.read_bytes())
else:
    sys.exit("colmeia-notificacoes: patch antigo sem original; reinstale o pacote")

texto = arq.read_text(encoding="utf-8")
antes = "width: Kirigami.Units.iconSizes.roundedIconSize(Math.min(parent.width, parent.height))\n"
depois = ("width: Math.min(Kirigami.Units.iconSizes.smallMedium, "
          f"Kirigami.Units.iconSizes.roundedIconSize(Math.min(parent.width, parent.height))) {MARCA}\n")
if antes not in texto:
    print("colmeia-notificacoes: AVISO trecho não encontrado", file=sys.stderr)
else:
    arq.write_text(texto.replace(antes, depois, 1), encoding="utf-8")
    print("colmeia-notificacoes: patch aplicado")
