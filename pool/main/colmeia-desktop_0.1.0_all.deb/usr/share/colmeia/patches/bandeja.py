#!/usr/bin/env python3
"""Bandeja do sistema no estilo do Windows 11 (patch sobre o KDE Plasma 6.3).

- setinha dos ícones escondidos à esquerda dos ícones;
- popup dos ícones escondidos pequeno, só com ícones em grade de 4 colunas,
  sem título nem nomes (os popups de volume, rede etc. continuam iguais).

Aplica sobre os arquivos instalados pelo Debian, para acompanhar a versão
do pacote. Cada troca é conferida; se o KDE mudar o arquivo, a troca é
pulada com aviso em vez de quebrar a bandeja.
"""
import sys
from pathlib import Path

UI = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/share/plasma/plasmoids/org.kde.plasma.private.systemtray/contents/ui")
MARCA = "// colmeia-bandeja"
CELULA = "(Kirigami.Units.iconSizes.smallMedium + Kirigami.Units.smallSpacing * 4)"
avisos = []
ARQUIVOS = ["main.qml", "ExpandedRepresentation.qml", "HiddenItemsView.qml",
            "items/AbstractItem.qml", "CurrentItemHighLight.qml", "ExpanderArrow.qml"]

# Sempre parte dos arquivos originais do KDE (cópia .colmeia-orig), para que
# rodar o patch de novo aplique a versão atual das trocas.
for nome in ARQUIVOS:
    arq = UI / nome
    orig = arq.with_name(arq.name + ".colmeia-orig")
    if MARCA not in arq.read_text(encoding="utf-8"):
        orig.write_bytes(arq.read_bytes())  # original do KDE (instalação nova ou atualização)
    elif orig.exists():
        arq.write_bytes(orig.read_bytes())
    else:
        sys.exit(f"colmeia-bandeja: {nome} já tem patch antigo e não há original; reinstale o plasma-workspace")


def trocar(nome, antes, depois):
    arq = UI / nome
    texto = arq.read_text(encoding="utf-8")
    if depois in texto:
        return
    if antes not in texto:
        avisos.append(f"{nome}: trecho não encontrado: {antes.strip()[:60]!r}")
        return
    arq.write_text(texto.replace(antes, depois, 1), encoding="utf-8")


def seta_a_esquerda():
    arq = UI / "main.qml"
    texto = arq.read_text(encoding="utf-8")
    if MARCA + " seta" in texto:
        return
    inicio = texto.find("            ExpanderArrow {")
    grade = texto.find("            GridView {\n                id: tasksGrid")
    if inicio < 0 or grade < 0 or grade > inicio:
        avisos.append("main.qml: não achei a seta ou a grade de ícones")
        return
    nivel, fim = 0, inicio
    for i in range(inicio, len(texto)):
        if texto[i] == "{":
            nivel += 1
        elif texto[i] == "}":
            nivel -= 1
            if nivel == 0:
                fim = i + 1
                break
    bloco = texto[inicio:fim] + "\n\n"
    resto = texto[:inicio].rstrip(" ") + texto[fim:].lstrip("\n")
    alvo = "            GridView {\n                id: tasksGrid"
    resto = resto.replace(alvo, f"            {MARCA} seta\n" + bloco + alvo, 1)
    arq.write_text(resto, encoding="utf-8")


seta_a_esquerda()

trocar("items/AbstractItem.qml",
       "            visible: abstractItem.inHiddenLayout\n",
       f"            {MARCA} AbstractItem.qml\n            visible: false\n")

trocar("HiddenItemsView.qml",
       "        readonly property int columns: 2\n",
       f"        {MARCA} HiddenItemsView.qml\n        readonly property int columns: 4\n")
trocar("HiddenItemsView.qml",
       "        cellWidth: Math.floor(hiddenTasksView.availableWidth / columns)\n        cellHeight: delegateHeight\n",
       f"        cellWidth: {CELULA}\n        cellHeight: cellWidth\n")

# grade centralizada: recuo no próprio ScrollView (não aumenta o conteúdo) e sem barras de rolagem
trocar("HiddenItemsView.qml",
       "    hoverEnabled: true\n    background: null\n",
       "    hoverEnabled: true\n    background: null\n"
       f"    {MARCA} centralizar\n"
       f"    leftPadding: Math.max(0, Math.floor((width - {CELULA} * Math.min(4, Math.max(1, hiddenTasks.count))) / 2))\n"
       "    rightPadding: 0\n"
       "    PlasmaComponents3.ScrollBar.horizontal.policy: PlasmaComponents3.ScrollBar.AlwaysOff\n"
       "    PlasmaComponents3.ScrollBar.vertical.policy: PlasmaComponents3.ScrollBar.AlwaysOff\n")

trocar("ExpandedRepresentation.qml",
       "    Layout.minimumWidth: Kirigami.Units.gridUnit * 24\n    Layout.minimumHeight: Kirigami.Units.gridUnit * 24\n",
       f"    {MARCA} ExpandedRepresentation.qml\n"
       f"    Layout.minimumWidth: systemTrayState.activeApplet ? Kirigami.Units.gridUnit * 24 : {CELULA} * Math.max(1, Math.min(4, hiddenLayout.itemCount)) + Kirigami.Units.largeSpacing * 2\n"
       f"    Layout.minimumHeight: systemTrayState.activeApplet ? Kirigami.Units.gridUnit * 24 : {CELULA} * Math.max(1, Math.ceil(hiddenLayout.itemCount / 4)) + Kirigami.Units.largeSpacing * 2\n"
       # só ícones: tamanho travado (o popup lembra o último tamanho usado)
       "    readonly property bool colmeiaSoIcones: !systemTrayState.activeApplet\n"
       "    Layout.preferredWidth: Layout.minimumWidth\n"
       "    Layout.preferredHeight: Layout.minimumHeight\n"
       "    Layout.maximumWidth: colmeiaSoIcones ? Layout.minimumWidth : Number.POSITIVE_INFINITY\n"
       "    Layout.maximumHeight: colmeiaSoIcones ? Layout.minimumHeight : Number.POSITIVE_INFINITY\n")
trocar("ExpandedRepresentation.qml",
       "        id: plasmoidHeading\n",
       "        id: plasmoidHeading\n        visible: !!systemTrayState.activeApplet\n")
trocar("ExpandedRepresentation.qml",
       "            id: trayHeading\n",
       "            id: trayHeading\n            visible: !!systemTrayState.activeApplet\n")

# sem a linha amarela de "item ativo" sobre a seta/ícone (o Windows 11 não tem)
trocar("CurrentItemHighLight.qml",
       "    opacity: systemTrayState.expanded ? 1 : 0\n",
       f"    {MARCA} CurrentItemHighLight.qml\n    opacity: 0\n")

# ícones pequenos no popup, como no Windows 11
trocar("items/AbstractItem.qml",
       "abstractItem.inVisibleLayout ? root.itemSize : Kirigami.Units.iconSizes.medium",
       "abstractItem.inVisibleLayout ? root.itemSize : Kirigami.Units.iconSizes.smallMedium")

# não destacar o primeiro ícone ao abrir (só com teclado, ao apertar uma seta)
trocar("HiddenItemsView.qml",
       "            if (activeFocus && currentIndex === -1) {\n                currentIndex = 0\n",
       "            if (activeFocus && currentIndex === -1) {\n                currentIndex = -1\n")
# A janela do popup guarda o maior tamanho usado (notificações, volume...).
# No modo só ícones, força a janela de volta ao tamanho da grade.
trocar("ExpandedRepresentation.qml",
       "import QtQuick\nimport QtQuick.Layouts\n",
       "import QtQuick\nimport QtQuick.Layouts\nimport QtQuick.Window\n")
trocar("ExpandedRepresentation.qml",
       "    property alias hiddenLayout: hiddenItemsView.layout\n",
       "    property alias hiddenLayout: hiddenItemsView.layout\n"
       f"    {MARCA} tamanho\n"
       "    function colmeiaAjustarJanela() {\n"
       "        const janela = popup.Window.window\n"
       "        if (!colmeiaSoIcones || !janela) return\n"
       "        janela.width = Layout.minimumWidth + (janela.leftPadding || 0) + (janela.rightPadding || 0)\n"
       "        janela.height = Layout.minimumHeight + (janela.topPadding || 0) + (janela.bottomPadding || 0)\n"
       "    }\n"
       "    onColmeiaSoIconesChanged: Qt.callLater(colmeiaAjustarJanela)\n"
       "    onVisibleChanged: if (visible) Qt.callLater(colmeiaAjustarJanela)\n")
# dica "Mostrar ícones ocultos" só com o popup fechado (aberto, ela tampava os ícones)
trocar("ExpanderArrow.qml",
       "    id: tooltip\n",
       f"    id: tooltip\n    {MARCA} ExpanderArrow.qml\n    active: !systemTrayState.expanded\n")
for aviso in avisos:
    print("colmeia-bandeja: AVISO", aviso, file=sys.stderr)
print("colmeia-bandeja: patch aplicado" + (" com avisos" if avisos else ""))
