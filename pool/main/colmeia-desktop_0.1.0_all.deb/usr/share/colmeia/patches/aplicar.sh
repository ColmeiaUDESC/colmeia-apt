#!/bin/sh
# Aplica (ou reaplica) os ajustes da Colmeia sobre componentes do KDE.
# Chamado na instalação e pelos gatilhos do dpkg quando o KDE é atualizado.
# Cada patch parte do arquivo original do KDE, então pode rodar várias vezes.
P=/usr/share/colmeia/patches

for patch in bandeja tarefas notificacoes painel area-de-trabalho; do
    python3 "$P/$patch.py" || echo "colmeia: falha ao aplicar $patch (o KDE mudou?)" >&2
done

# Atalhos do KDE que a Colmeia troca ou esconde.
# /usr/local/share/applications tem prioridade e não é tocado pelo dpkg.
mkdir -p /usr/local/share/applications
if [ -f /usr/share/applications/org.kde.plasma-welcome.desktop ]; then
    sed -e 's/^Icon=.*/Icon=colmeia/' -e 's/^Name=.*/Name=Boas-vindas à Colmeia/' \
        -e '/^Name\[/d' /usr/share/applications/org.kde.plasma-welcome.desktop \
        > /usr/local/share/applications/org.kde.plasma-welcome.desktop
fi
if [ -f /usr/share/applications/org.kde.khelpcenter.desktop ]; then
    { cat /usr/share/applications/org.kde.khelpcenter.desktop; echo 'NoDisplay=true'; } \
        > /usr/local/share/applications/org.kde.khelpcenter.desktop
fi
exit 0
