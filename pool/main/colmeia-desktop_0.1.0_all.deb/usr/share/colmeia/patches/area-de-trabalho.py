#!/usr/bin/env python3
"""Menu do botão direito da área de trabalho na ordem do Windows (patch sobre o KDE Plasma 6.3).

    Exibir ▸ (tamanho dos ícones, classificar, organizar, alinhar)
    Atualizar
    ─
    Colar
    Desfazer
    Esvaziar lixeira (só quando aplicável)
    ─
    Abrir terminal aqui
    ─
    Novo ▸
    ─
    Configurações de exibição
    Personalizar

As ações do plugin de menu do KDE (configurar, tela, bloquear...) são
desligadas em plasma-org.kde.plasma.desktop-appletsrc (ver /etc/skel).
Sempre parte do original (.colmeia-orig), então pode rodar de novo.
"""
import sys
from pathlib import Path

UI = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/share/plasma/plasmoids/org.kde.desktopcontainment/contents/ui")
MARCA = "// colmeia-area-de-trabalho"

arq = UI / "FolderViewLayer.qml"
orig = arq.with_name(arq.name + ".colmeia-orig")
if MARCA not in arq.read_text(encoding="utf-8"):
    orig.write_bytes(arq.read_bytes())  # original do KDE (instalação nova ou atualização)
elif orig.exists():
    arq.write_bytes(orig.read_bytes())
else:
    sys.exit("colmeia-area-de-trabalho: patch antigo sem original; reinstale o plasma-desktop-data")

texto = arq.read_text(encoding="utf-8")
avisos = []


def trocar(antes, depois):
    global texto
    if antes not in texto:
        avisos.append(f"trecho não encontrado: {antes.strip()[:60]!r}")
        return
    texto = texto.replace(antes, depois, 1)


trocar("import org.kde.private.desktopcontainment.folder as Folder\n",
       "import org.kde.private.desktopcontainment.folder as Folder\n"
       "import org.kde.plasma.plasma5support as P5Support\n")

trocar('        text: i18n("Icons")\n        icon.name: "view-list-icons"\n',
       '        text: "Exibir"\n        icon.name: "view-list-icons"\n')

NOVO = f'''    {MARCA}: ações extras e ordem do menu como no Windows
    P5Support.DataSource {{
        id: colmeiaExecutar
        engine: "executable"
        connectedSources: []
        onNewData: function(fonte, dados) {{ disconnectSource(fonte) }}
        function rodar(comando) {{ connectSource(comando) }}
    }}
    PlasmaCore.Action {{
        id: colmeiaSep1
        isSeparator: true
    }}
    PlasmaCore.Action {{
        id: colmeiaSep2
        isSeparator: true
    }}
    PlasmaCore.Action {{
        id: colmeiaSep3
        isSeparator: true
    }}
    PlasmaCore.Action {{
        id: colmeiaTerminal
        text: "Abrir terminal aqui"
        icon.name: "utilities-terminal"
        onTriggered: colmeiaExecutar.rodar("sh -c 'konsole --workdir \\"$(xdg-user-dir DESKTOP)\\"'")
    }}
    PlasmaCore.Action {{
        id: colmeiaTela
        text: "Configurações de exibição"
        icon.name: "preferences-desktop-display"
        onTriggered: colmeiaExecutar.rodar("kcmshell6 kcm_kscreen")
    }}
    PlasmaCore.Action {{
        id: colmeiaPersonalizar
        text: "Personalizar"
        icon.name: "preferences-desktop-wallpaper"
        onTriggered: {{
            const configurar = Plasmoid.internalAction("configure");
            if (configurar) {{
                configurar.trigger();
            }}
        }}
    }}

    Component.onCompleted: {{
        if (!isContainment) {{
            label = labelComponent.createObject(folderViewLayerComponent);
        }}

        const modelo = folderView.model;
        const ordem = [
            viewPropertiesAction,
            modelo.action("refresh"),
            colmeiaSep1,
            modelo.action("paste"),
            modelo.action("undo"),
            modelo.action("emptyTrash"),
            actionSeparator,
            colmeiaTerminal,
            colmeiaSep2,
            modelo.action("newMenu"),
            colmeiaSep3,
            colmeiaTela,
            colmeiaPersonalizar,
        ];
        for (const acao of ordem) {{
            if (acao) {{
                Plasmoid.contextualActions.push(acao);
            }}
        }}

        Plasmoid.contextualActionsAboutToShow.connect(updateContextualActions);
        Plasmoid.contextualActionsAboutToShow.connect(folderView.model.clearSelection);
    }}
}}
'''

inicio = texto.find("    Component.onCompleted: {\n        if (!isContainment) {")
if inicio < 0:
    avisos.append("Component.onCompleted não encontrado")
else:
    texto = texto[:inicio] + NOVO

arq.write_text(texto, encoding="utf-8")
for aviso in avisos:
    print("colmeia-area-de-trabalho: AVISO", aviso, file=sys.stderr)
print("colmeia-area-de-trabalho: patch aplicado" + (" com avisos" if avisos else ""))
