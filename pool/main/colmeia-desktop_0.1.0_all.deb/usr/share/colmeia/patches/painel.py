#!/usr/bin/env python3
"""Menu do botão direito da barra de tarefas no estilo do Windows (patch sobre o KDE Plasma 6.3).

Acrescenta ao contêiner do painel (org.kde.panel) ações como as do Windows:
Gerenciador de Tarefas, Mostrar a área de trabalho e Visão geral das janelas.
As opções do KDE (adicionar widgets, configurar painel) continuam no menu.
Sempre parte do original (.colmeia-orig), então pode rodar de novo.
"""
import sys
from pathlib import Path

UI = Path(sys.argv[1] if len(sys.argv) > 1 else
          "/usr/share/plasma/plasmoids/org.kde.panel/contents/ui")
MARCA = "// colmeia-painel"

arq = UI / "main.qml"
orig = arq.with_name(arq.name + ".colmeia-orig")
if MARCA not in arq.read_text(encoding="utf-8"):
    orig.write_bytes(arq.read_bytes())  # original do KDE (instalação nova ou atualização)
elif orig.exists():
    arq.write_bytes(orig.read_bytes())
else:
    sys.exit("colmeia-painel: patch antigo sem original; reinstale o plasma-desktop-data")

texto = arq.read_text(encoding="utf-8")
avisos = []


def trocar(antes, depois):
    global texto
    if antes not in texto:
        avisos.append(f"trecho não encontrado: {antes.strip()[:60]!r}")
        return
    texto = texto.replace(antes, depois, 1)


trocar("import org.kde.kirigami 2.20 as Kirigami\n",
       "import org.kde.kirigami 2.20 as Kirigami\n"
       "import org.kde.plasma.plasma5support as P5Support\n")

ACOES = f'''ContainmentItem {{
    id: root

    {MARCA}: ações do botão direito como na barra do Windows
    P5Support.DataSource {{
        id: colmeiaExecutar
        engine: "executable"
        connectedSources: []
        onNewData: function(fonte, dados) {{ disconnectSource(fonte) }}
        function rodar(comando) {{ connectSource(comando) }}
    }}
    function colmeiaAtalhoKWin(nome) {{
        colmeiaExecutar.rodar("gdbus call --session --dest org.kde.kglobalaccel --object-path /component/kwin "
            + "--method org.kde.kglobalaccel.Component.invokeShortcut '" + nome + "'")
    }}

    Plasmoid.contextualActions: [
        PlasmaCore.Action {{
            text: "Gerenciador de Tarefas"
            icon.name: "utilities-system-monitor"
            onTriggered: colmeiaExecutar.rodar("plasma-systemmonitor")
        }},
        PlasmaCore.Action {{
            isSeparator: true
        }},
        PlasmaCore.Action {{
            text: "Mostrar a área de trabalho"
            icon.name: "user-desktop"
            onTriggered: root.colmeiaAtalhoKWin("Show Desktop")
        }},
        PlasmaCore.Action {{
            text: "Visão geral das janelas"
            icon.name: "view-app-grid-symbolic"
            onTriggered: root.colmeiaAtalhoKWin("Overview")
        }}
    ]
'''
trocar("ContainmentItem {\n    id: root\n", ACOES)

arq.write_text(texto, encoding="utf-8")
for aviso in avisos:
    print("colmeia-painel: AVISO", aviso, file=sys.stderr)
print("colmeia-painel: patch aplicado" + (" com avisos" if avisos else ""))
