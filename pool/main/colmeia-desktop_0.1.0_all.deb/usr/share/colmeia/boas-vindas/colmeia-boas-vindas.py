#!/usr/bin/env python3
"""Boas-vindas à Colmeia: primeiro contato do estudante com a Colmeia Linux."""
import configparser
import os
import shlex
import sys
from pathlib import Path

from PySide6.QtCore import QObject, QProcess, QUrl, Property, Slot
from PySide6.QtGui import QDesktopServices, QGuiApplication, QIcon
from PySide6.QtQml import QQmlApplicationEngine
from PySide6.QtQuickControls2 import QQuickStyle

AQUI = Path(__file__).resolve().parent
ARTE = AQUI.parent / "artwork"
CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "colmeia-boas-vindas.conf"
INSTALADOR = Path("/usr/share/applications/calamares-install-debian.desktop")


def sessao_live():
    try:
        return "boot=live" in Path("/proc/cmdline").read_text()
    except OSError:
        return False


def comando_do_atalho(atalho):
    """Lê a linha Exec de um arquivo .desktop, sem os códigos %f, %u etc."""
    for linha in atalho.read_text(encoding="utf-8").splitlines():
        if linha.startswith("Exec="):
            return [p for p in shlex.split(linha[5:]) if not p.startswith("%")]
    return []


class Sistema(QObject):
    def __init__(self):
        super().__init__()
        self._config = configparser.ConfigParser()
        self._config.read(CONFIG)

    @Property(bool, constant=True)
    def live(self):
        return sessao_live()

    @Property(str, constant=True)
    def arte(self):
        return QUrl.fromLocalFile(str(ARTE)).toString()

    @Property(str, constant=True)
    def icones(self):
        return QUrl.fromLocalFile(str(AQUI / "icones")).toString()

    @Property(bool, constant=True)
    def mostrarAoIniciar(self):
        return self._config.getboolean("Geral", "MostrarAoIniciar", fallback=True)

    @Slot(bool)
    def definirMostrarAoIniciar(self, valor):
        if not self._config.has_section("Geral"):
            self._config.add_section("Geral")
        self._config.set("Geral", "MostrarAoIniciar", "true" if valor else "false")
        CONFIG.parent.mkdir(parents=True, exist_ok=True)
        with CONFIG.open("w", encoding="utf-8") as arquivo:
            self._config.write(arquivo)

    @Slot(str)
    def abrir(self, comando):
        partes = shlex.split(os.path.expandvars(os.path.expanduser(comando)))
        if partes:
            QProcess.startDetached(partes[0], partes[1:])

    @Slot(str)
    def abrirLink(self, endereco):
        QDesktopServices.openUrl(QUrl(endereco))

    @Slot()
    def instalar(self):
        if INSTALADOR.exists():
            partes = comando_do_atalho(INSTALADOR)
            if partes:
                QProcess.startDetached(partes[0], partes[1:])


def main():
    autostart = "--autostart" in sys.argv
    app = QGuiApplication(sys.argv)
    app.setApplicationName("colmeia-boas-vindas")
    app.setApplicationDisplayName("Boas-vindas à Colmeia")
    app.setDesktopFileName("colmeia-boas-vindas")
    app.setWindowIcon(QIcon(str(ARTE / "colmeia-icone.png")))

    sistema = Sistema()
    if autostart and not sistema.mostrarAoIniciar and not sistema.live:
        return 0

    QQuickStyle.setStyle("Basic")
    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("sistema", sistema)
    engine.load(QUrl.fromLocalFile(str(AQUI / "main.qml")))
    if not engine.rootObjects():
        return 1
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
