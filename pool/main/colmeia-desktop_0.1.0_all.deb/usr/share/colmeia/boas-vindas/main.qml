import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Window

ApplicationWindow {
    id: janela
    width: 1040
    height: 680
    minimumWidth: 860
    minimumHeight: 580
    visible: true
    title: "Boas-vindas à Colmeia"
    color: cor.fundo

    QtObject {
        id: cor
        readonly property color mel: "#ffcd2c"
        readonly property color melEscuro: "#9a6a00"
        readonly property color creme: "#ffe4a5"
        readonly property color grafite: "#414042"
        readonly property color grafiteEscuro: "#2a292b"
        readonly property color fundo: "#fffbef"
        readonly property color cartao: "#ffffff"
        readonly property color borda: "#f0dfae"
        readonly property color texto: "#2a292b"
        readonly property color textoSuave: "#5e5a52"
        readonly property color claro: "#f5f1e6"
    }

    property int pagina: 0
    readonly property var paginas: [
        { titulo: "Início", icone: "inicio" },
        { titulo: "Vindo do Windows?", icone: "windows" },
        { titulo: "Programar", icone: "codigo" },
        { titulo: "Instalar programas", icone: "loja" },
        { titulo: "Comunidade", icone: "comunidade" }
    ]

    function icone(nome, variante) {
        return sistema.icones + "/" + nome + (variante ? "-" + variante : "") + ".svg"
    }

    component Hexagono: Canvas {
        property color preenchimento: cor.mel
        property color contorno: "transparent"
        property real espessura: 0
        onPreenchimentoChanged: requestPaint()
        onContornoChanged: requestPaint()
        onPaint: {
            var c = getContext("2d")
            c.reset()
            var r = Math.min(width / 1.732, height / 2) - espessura
            var cx = width / 2, cy = height / 2
            c.beginPath()
            for (var i = 0; i < 6; i++) {
                var a = Math.PI / 180 * (60 * i - 90)
                var x = cx + r * Math.cos(a), y = cy + r * Math.sin(a)
                if (i === 0) c.moveTo(x, y); else c.lineTo(x, y)
            }
            c.closePath()
            c.fillStyle = preenchimento
            c.fill()
            if (espessura > 0) {
                c.lineWidth = espessura
                c.strokeStyle = contorno
                c.stroke()
            }
        }
    }

    component Titulo: Label {
        color: cor.texto
        font.pixelSize: 30
        font.weight: Font.ExtraBold
        wrapMode: Text.WordWrap
        Layout.fillWidth: true
    }

    component Paragrafo: Label {
        color: cor.textoSuave
        font.pixelSize: 15
        lineHeight: 1.35
        wrapMode: Text.WordWrap
        textFormat: Text.StyledText
        Layout.fillWidth: true
    }

    component Botao: Button {
        id: botao
        property bool principal: false
        property string nomeIcone: ""
        hoverEnabled: true
        font.pixelSize: 14
        font.weight: Font.Bold
        leftPadding: 20
        rightPadding: 20
        topPadding: 11
        bottomPadding: 11
        contentItem: RowLayout {
            spacing: 8
            Image {
                visible: botao.nomeIcone !== ""
                source: botao.nomeIcone !== "" ? janela.icone(botao.nomeIcone) : ""
                sourceSize: Qt.size(18, 18)
                Layout.preferredWidth: 18
                Layout.preferredHeight: 18
            }
            Label {
                text: botao.text
                font: botao.font
                color: cor.texto
            }
        }
        background: Rectangle {
            radius: 10
            color: botao.principal ? (botao.down ? "#f2b800" : cor.mel) : (botao.hovered ? cor.creme : "transparent")
            border.color: cor.mel
            border.width: 2
        }
    }

    component Cartao: AbstractButton {
        id: cartao
        property string nomeIcone: "link"
        property string titulo: ""
        property string texto: ""
        property string comando: ""
        property string link: ""
        property string antes: ""
        readonly property bool clicavel: comando !== "" || link !== ""
        hoverEnabled: true
        padding: 18
        Layout.fillWidth: true
        Layout.preferredHeight: 104
        onClicked: {
            if (comando !== "") sistema.abrir(comando)
            else if (link !== "") sistema.abrirLink(link)
        }
        HoverHandler { cursorShape: cartao.clicavel ? Qt.PointingHandCursor : Qt.ArrowCursor }
        background: Rectangle {
            radius: 14
            color: cor.cartao
            border.color: cartao.clicavel && cartao.hovered ? cor.mel : cor.borda
            border.width: cartao.clicavel && cartao.hovered ? 2 : 1
        }
        contentItem: RowLayout {
            spacing: 16
            Item {
                Layout.preferredWidth: 52
                Layout.preferredHeight: 60
                Hexagono {
                    anchors.fill: parent
                    preenchimento: cor.mel
                    rotation: cartao.clicavel && cartao.hovered ? 30 : 0
                    Behavior on rotation { NumberAnimation { duration: 180 } }
                }
                Image {
                    anchors.centerIn: parent
                    source: janela.icone(cartao.nomeIcone)
                    sourceSize: Qt.size(26, 26)
                }
            }
            ColumnLayout {
                spacing: 3
                Layout.fillWidth: true
                Label {
                    visible: cartao.antes !== ""
                    text: cartao.antes
                    color: cor.melEscuro
                    font.pixelSize: 11
                    font.weight: Font.Bold
                    font.capitalization: Font.AllUppercase
                    font.letterSpacing: 1
                }
                Label {
                    text: cartao.titulo
                    color: cor.texto
                    font.pixelSize: 16
                    font.weight: Font.Bold
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
                Label {
                    text: cartao.texto
                    color: cor.textoSuave
                    font.pixelSize: 13
                    wrapMode: Text.WordWrap
                    Layout.fillWidth: true
                }
            }
            Image {
                visible: cartao.clicavel
                source: janela.icone("link")
                sourceSize: Qt.size(16, 16)
                opacity: cartao.hovered ? 1 : 0.4
                Layout.alignment: Qt.AlignTop
            }
        }
    }

    component Aviso: Rectangle {
        property alias texto: rotulo.text
        property string nomeIcone: "aviso"
        Layout.fillWidth: true
        implicitHeight: linhaAviso.implicitHeight + 28
        radius: 12
        color: "#fff1c9"
        border.color: cor.mel
        RowLayout {
            id: linhaAviso
            anchors.fill: parent
            anchors.margins: 14
            spacing: 12
            Image {
                source: janela.icone(parent.parent.nomeIcone)
                sourceSize: Qt.size(22, 22)
                Layout.alignment: Qt.AlignTop
            }
            Label {
                id: rotulo
                color: cor.texto
                font.pixelSize: 13
                wrapMode: Text.WordWrap
                textFormat: Text.StyledText
                Layout.fillWidth: true
            }
        }
    }

    component Pagina: ScrollView {
        default property alias conteudo: coluna.data
        contentWidth: availableWidth
        clip: true
        ColumnLayout {
            id: coluna
            width: parent.width
            spacing: 18
            Item { Layout.preferredHeight: 18 }
        }
    }

    RowLayout {
        anchors.fill: parent
        spacing: 0

        Rectangle {
            Layout.fillHeight: true
            Layout.preferredWidth: 250
            color: cor.grafiteEscuro

            ColumnLayout {
                anchors.fill: parent
                anchors.margins: 18
                spacing: 6

                Image {
                    source: sistema.arte + "/colmeia-logo-claro-520.png"
                    sourceSize.width: 190
                    fillMode: Image.PreserveAspectFit
                    Layout.preferredWidth: 190
                    Layout.topMargin: 10
                    Layout.bottomMargin: 26
                    Layout.alignment: Qt.AlignHCenter
                }

                Repeater {
                    model: janela.paginas
                    delegate: AbstractButton {
                        id: item
                        required property var modelData
                        required property int index
                        readonly property bool atual: janela.pagina === index
                        hoverEnabled: true
                        Layout.fillWidth: true
                        Layout.preferredHeight: 44
                        onClicked: janela.pagina = index
                        HoverHandler { cursorShape: Qt.PointingHandCursor }
                        background: Rectangle {
                            radius: 10
                            color: item.atual ? cor.mel : (item.hovered ? "#3a393c" : "transparent")
                        }
                        contentItem: RowLayout {
                            spacing: 12
                            Image {
                                source: janela.icone(item.modelData.icone, item.atual ? "" : "claro")
                                sourceSize: Qt.size(20, 20)
                                Layout.leftMargin: 6
                            }
                            Label {
                                text: item.modelData.titulo
                                color: item.atual ? cor.grafiteEscuro : cor.claro
                                font.pixelSize: 14
                                font.weight: item.atual ? Font.Bold : Font.Medium
                                Layout.fillWidth: true
                            }
                        }
                    }
                }

                Item { Layout.fillHeight: true }

                Botao {
                    visible: sistema.live
                    principal: true
                    nomeIcone: "instalar"
                    text: "Instalar a Colmeia"
                    Layout.fillWidth: true
                    onClicked: sistema.instalar()
                }

                CheckBox {
                    id: mostrar
                    visible: !sistema.live
                    checked: sistema.mostrarAoIniciar
                    text: "Mostrar ao iniciar"
                    onToggled: sistema.definirMostrarAoIniciar(checked)
                    Layout.topMargin: 6
                    indicator: Rectangle {
                        x: mostrar.leftPadding
                        anchors.verticalCenter: parent.verticalCenter
                        width: 20
                        height: 20
                        radius: 5
                        color: mostrar.checked ? cor.mel : "transparent"
                        border.color: cor.mel
                        border.width: 2
                        Label {
                            anchors.centerIn: parent
                            visible: mostrar.checked
                            text: "✓"
                            color: cor.grafiteEscuro
                            font.pixelSize: 13
                            font.weight: Font.Bold
                        }
                    }
                    contentItem: Label {
                        leftPadding: mostrar.indicator.width + 10
                        text: mostrar.text
                        color: cor.claro
                        font.pixelSize: 13
                        verticalAlignment: Text.AlignVCenter
                    }
                }
            }
        }

        ColumnLayout {
            Layout.fillWidth: true
            Layout.fillHeight: true
            spacing: 0

            StackLayout {
                currentIndex: janela.pagina
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.leftMargin: 40
                Layout.rightMargin: 40

                Pagina {
                    RowLayout {
                        spacing: 24
                        Layout.fillWidth: true
                        ColumnLayout {
                            spacing: 14
                            Layout.fillWidth: true
                            Label {
                                text: "OLÁ, ESTUDANTE!"
                                color: cor.melEscuro
                                font.pixelSize: 13
                                font.weight: Font.Bold
                                font.letterSpacing: 1.5
                            }
                            Titulo { text: "Bem-vindos ao Colmeia" }
                            Paragrafo {
                                text: "A Colmeia é uma distribuição Linux feita pelo grupo de extensão <b>Colmeia</b>, da UDESC, " +
                                      "para quem está começando no Linux e na programação. Tudo aqui é software livre: " +
                                      "você pode usar, estudar, modificar e compartilhar."
                            }
                            Paragrafo {
                                text: "Use o menu ao lado para conhecer o sistema. Leva só alguns minutos."
                            }
                            RowLayout {
                                spacing: 12
                                Layout.topMargin: 6
                                Botao {
                                    principal: true
                                    text: "Começar o tour  →"
                                    onClicked: janela.pagina = 1
                                }
                                Botao {
                                    nomeIcone: "livro"
                                    text: "Abrir o guia"
                                    onClicked: sistema.abrir("xdg-open /usr/share/colmeia/welcome/index.html")
                                }
                            }
                        }
                        Image {
                            source: sistema.arte + "/mascote.png"
                            sourceSize.width: 280
                            fillMode: Image.PreserveAspectFit
                            Layout.preferredWidth: 260
                            Layout.preferredHeight: 260
                        }
                    }
                    Aviso {
                        visible: sistema.live
                        nomeIcone: "instalar"
                        texto: "<b>Você está no modo de teste.</b> Nada foi instalado no seu computador e o que você fizer aqui " +
                               "some ao desligar. Gostou? Use o botão <b>Instalar a Colmeia</b> no canto inferior esquerdo."
                    }
                    GridLayout {
                        columns: 3
                        columnSpacing: 14
                        rowSpacing: 14
                        Layout.fillWidth: true
                        Layout.topMargin: 6
                        Cartao { nomeIcone: "pasta"; titulo: "Arquivos"; texto: "Seus documentos e pastas"; comando: "dolphin" }
                        Cartao { nomeIcone: "config"; titulo: "Configurações"; texto: "Aparência, rede, som e mais"; comando: "systemsettings" }
                        Cartao { nomeIcone: "loja"; titulo: "Programas"; texto: "Instale apps livres"; comando: "plasma-discover" }
                    }
                }

                Pagina {
                    Titulo { text: "Vindo do Windows?" }
                    Paragrafo {
                        text: "Quase tudo tem um equivalente na Colmeia. Clique para abrir e experimentar."
                    }
                    GridLayout {
                        columns: 2
                        columnSpacing: 14
                        rowSpacing: 14
                        Layout.fillWidth: true
                        Cartao { antes: "Menu Iniciar"; nomeIcone: "menu"; titulo: "Menu da Colmeia"; texto: "O hexágono no canto esquerdo do painel. Digite para pesquisar." }
                        Cartao { antes: "Explorador de Arquivos"; nomeIcone: "pasta"; titulo: "Dolphin"; texto: "Pastas, pendrives e arquivos"; comando: "dolphin" }
                        Cartao { antes: "Painel de Controle"; nomeIcone: "config"; titulo: "Configurações do sistema"; texto: "Aparência, rede, usuários e mais"; comando: "systemsettings" }
                        Cartao { antes: "Microsoft Store"; nomeIcone: "loja"; titulo: "Discover"; texto: "Loja de aplicativos livres"; comando: "plasma-discover" }
                        Cartao { antes: "Bloco de Notas"; nomeIcone: "caderno"; titulo: "Kate"; texto: "Editor de texto com cores para código"; comando: "kate" }
                        Cartao { antes: "Prompt de Comando"; nomeIcone: "terminal"; titulo: "Konsole"; texto: "O terminal, onde você digita comandos"; comando: "konsole" }
                    }
                    Aviso {
                        texto: "<b>Programas .exe não funcionam direto no Linux.</b> Para quase todos existe uma alternativa livre: " +
                               "o LibreOffice no lugar do Office, o GIMP no lugar do Photoshop, o VSCodium no lugar do VS Code."
                    }
                }

                Pagina {
                    Titulo { text: "Programar" }
                    Paragrafo {
                        text: "A Colmeia já vem pronta para as disciplinas: C e C++, Python, Java, JavaScript, SQL e Git. " +
                              "Na sua pasta <b>Projetos</b> tem exemplos para cada linguagem."
                    }
                    GridLayout {
                        columns: 2
                        columnSpacing: 14
                        rowSpacing: 14
                        Layout.fillWidth: true
                        Cartao { nomeIcone: "codigo"; titulo: "VSCodium"; texto: "Editor de código completo e livre"; comando: "codium" }
                        Cartao { nomeIcone: "pasta"; titulo: "Meus primeiros projetos"; texto: "Exemplos em C, Python, Java, SQL e web"; comando: "dolphin $HOME/Projetos/primeiros-passos" }
                        Cartao { nomeIcone: "terminal"; titulo: "Terminal"; texto: "Compile e rode seus programas"; comando: "konsole" }
                        Cartao { nomeIcone: "caderno"; titulo: "Jupyter Notebook"; texto: "Python interativo, ótimo para dados"; comando: "jupyter-notebook" }
                    }
                    Aviso {
                        nomeIcone: "terminal"
                        texto: "Primeiro programa em C: abra o terminal na pasta do exemplo e digite " +
                               "<b>gcc ola.c -o ola</b> e depois <b>./ola</b>"
                    }
                }

                Pagina {
                    Titulo { text: "Instalar programas" }
                    Paragrafo {
                        text: "No Linux os programas vêm de repositórios confiáveis, sem precisar procurar instaladores na internet. " +
                              "As atualizações também chegam por lá."
                    }
                    Cartao {
                        nomeIcone: "loja"
                        titulo: "Abrir o Discover"
                        texto: "Pesquise, leia avaliações e instale com um clique. Também é por ele que o sistema se atualiza."
                        comando: "plasma-discover"
                    }
                    Aviso {
                        nomeIcone: "terminal"
                        texto: "Pelo terminal também dá: <b>sudo apt install nome-do-programa</b>. " +
                               "Para atualizar tudo: <b>sudo apt update</b> e depois <b>sudo apt upgrade</b>."
                    }
                }

                Pagina {
                    Titulo { text: "Comunidade" }
                    Paragrafo {
                        text: "O Colmeia existe desde 2002 levando software e hardware livre para escolas, universidades e para a comunidade. " +
                              "Qualquer pessoa pode participar, não precisa ser da Computação."
                    }
                    GridLayout {
                        columns: 2
                        columnSpacing: 14
                        rowSpacing: 14
                        Layout.fillWidth: true
                        Cartao { nomeIcone: "inicio"; titulo: "Site do Colmeia"; texto: "colmeiaudesc.github.io"; link: "https://colmeiaudesc.github.io/" }
                        Cartao { nomeIcone: "codigo"; titulo: "GitHub"; texto: "Código da Colmeia Linux e do site"; link: "https://github.com/colmeiaUDESC" }
                        Cartao { nomeIcone: "comunidade"; titulo: "Instagram"; texto: "@colmeiaudesc"; link: "https://instagram.com/colmeiaudesc" }
                        Cartao { nomeIcone: "windows"; titulo: "YouTube"; texto: "Minicursos e vídeos"; link: "https://www.youtube.com/channel/UC51KrWL94AfGxI_4l_E7uzA" }
                    }
                    Aviso {
                        nomeIcone: "comunidade"
                        texto: "A Colmeia Linux é construída sobre o <b>Debian</b> e o <b>KDE Plasma</b>, feitos por comunidades " +
                               "voluntárias do mundo todo. Obrigado a elas! Saiba mais em debian.org e kde.org."
                    }
                }
            }

            Rectangle {
                Layout.fillWidth: true
                Layout.preferredHeight: 1
                color: cor.borda
            }

            RowLayout {
                Layout.fillWidth: true
                Layout.preferredHeight: 68
                Layout.leftMargin: 40
                Layout.rightMargin: 40
                spacing: 12

                Botao {
                    text: "←  Voltar"
                    opacity: janela.pagina > 0 ? 1 : 0
                    enabled: janela.pagina > 0
                    onClicked: janela.pagina--
                }
                Item { Layout.fillWidth: true }
                Row {
                    spacing: 8
                    Repeater {
                        model: janela.paginas.length
                        delegate: Hexagono {
                            required property int index
                            width: 14
                            height: 16
                            preenchimento: index === janela.pagina ? cor.mel : "transparent"
                            contorno: cor.mel
                            espessura: 1.6
                        }
                    }
                }
                Item { Layout.fillWidth: true }
                Botao {
                    principal: true
                    text: janela.pagina < janela.paginas.length - 1 ? "Próximo  →" : "Concluir"
                    onClicked: {
                        if (janela.pagina < janela.paginas.length - 1) janela.pagina++
                        else Qt.quit()
                    }
                }
            }
        }
    }
}
